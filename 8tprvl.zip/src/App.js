import { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import "./App.css";

function App() {
  const data = [
    {
      name: "John Doe",
      desig: "Product"
    },
    {
      name: "Tim Cook",
      desig: "Engineering"
    },
    {
      name: "Johnny Dep",
      desig: "Product"
    },
    {
      name: "Clever Bob",
      desig: "Engineering"
    }
  ];
  const [showModal, setShow] = useState(false);
  const [details, setDetails] = useState(data);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleSearch = (event) => {
    if (event.target.value === "") {
      setDetails(data);
      return;
    }
    const filteredValues = details.filter((item) => (entry) =>
      Object.values(details).some(
        (val) => typeof val === "string" && val.includes(event.target.value)
      )
    );
    setDetails(filteredValues);
  };
  return (
    <div className="App">
      <div
        className="d-flex align-items-center justify-content-center"
        style={{ height: "100vh" }}
      >
        <Button variant="primary" onClick={handleShow}>
          Share
        </Button>
      </div>
      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header closeButton>
          <h2 className="share">Share to Web</h2>
          <p className="publish">Publish and Share Link with anyone</p>
        </Modal.Header>
        <Modal.Body>
          <input type="text" onClick={(e) => handleSearch} />
          <button>Invite</button>
          {}
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </div>
  );
}

export default App;
